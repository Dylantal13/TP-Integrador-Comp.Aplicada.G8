history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
vi /etc/hosts
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir
vi /etc/fstab
mount -a
cat /proc/partitions > /opt/particion
vi /etc/network/interfaces
ifdown enp0s3 && ifup enp0s3
ifdown enp0s3
ifup enp0s3
ping -c 4 google.com
vi /etc/default/grub
update-grub
echo "nameserver 8.8.8.8" > /etc/resolv.conf
echo "deb http://deb.debian.org/debian bookworm main" > /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main" >> /etc/apt/sources.list
apt update
apt full-upgrade -y
apt autoremove -y
reboot
