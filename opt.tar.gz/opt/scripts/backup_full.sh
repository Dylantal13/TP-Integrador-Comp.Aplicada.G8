#!/bin/bash
# 1 Opcion de ayuda
if [ "$1" == "-help" ]; then
echo "Uso: $o <origen> <destino> <nombre_base>"
echo "Ejemplo: $o /var/log /backup_dir log"
exit 0
fi

#2 Variables
ORIGEN=$1
DESTINO=$2
NOMBRE=$3
FECHA=$(date +%Y%m%d)
#3 Validacion de origen y destino
if [ ! -d "$ORIGEN" ]; then
echo "Error: El directorio origen ($ORIGEN) no existe"
exit 1
fi
if [ ! -d "$DESTINO" ], then
echo "Error: EL directorio destino ($DESTINO) no existe"
exit 1
fi
#4 Ejecucion del backup
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGNE"
